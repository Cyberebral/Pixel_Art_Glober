the purpose of this executable is to demonstrate pixel art and maybe some development skills.
All sprites, sounds, code and font are made by me.

Made by: Neal Finger
Made in: Game Maker Studio 2

Controls: wasd or arrows to move

objective: eat all food
